<div class="container">
    <div class="row">
        <div class="col-md-8 col-md-offset-2">
            <div class="panel panel-default">
                <div class="panel-heading">Registro de Depositos</div>
                <div class="panel-body">
                <div class="alert alert-info alert-dismissable fade in">
                <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
                <strong>Info!</strong> Antes de realizar un Depósito debes verificar en tu dashboard cuanto puedes invertir de acuerdo al Plan que selecciones. Recuerda colocar el link con el código de operación generado por tu wallet.
              </div>
                 <?php if(session()->has('msj')): ?>
                   <div class="alert alert-success alert-dismissable">
                    <a href="#" class="close" data-dismiss="alert" aria-label="close">×</a>
                    <strong><?php echo e(session('msj')); ?></strong>
                  </div>
                 <?php endif; ?>
                 <?php if(session()->has('errormsj')): ?>
                   <div class="alert alert-danger alert-dismissable">
                    <a href="#" class="close" data-dismiss="alert" aria-label="close">×</a>
                    <strong><?php echo e(session('errormsj')); ?></strong>
                   </div>
                 <?php endif; ?>
                    <form class="form-horizontal" role="form" method="POST" action="<?php echo e(url('deposit')); ?>">
                        <?php echo e(csrf_field()); ?>

                        
                        <div class="form-group<?php echo e($errors->has('description') ? ' has-error' : ''); ?>">
                            <label for="description" class="col-md-4 control-label">Plan</label>

                            <div class="col-md-6">
                                <select name="plan_id" id="plan_id" class="form-control" >
                                    <?php $__currentLoopData = $plans; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                      <option value="<?php echo e($p->id); ?>"><?php echo e($p->description.' Ganancia '.$p->porcmax.'% Inversión:'.$p->invmin.'-'.$p->invmax.'$'); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    
                                    
                                </select>

                                <?php if($errors->has('description')): ?>
                                    <span class="help-block">
                                        <strong><?php echo e($errors->first('description')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                        </div>

                
                        <div class="form-group<?php echo e($errors->has('hash') ? ' has-error' : ''); ?>">
                            <label for="hash" class="col-md-4 control-label">Hash</label>

                            <div class="col-md-6">
                                <input id="hash" type="text" class="form-control" name="hash" value="<?php echo e(old('hash')); ?>" required autofocus>

                                <?php if($errors->has('hash')): ?>
                                    <span class="help-block">
                                        <strong><?php echo e($errors->first('hash')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                        </div>

                        <div class="form-group<?php echo e($errors->has('amount') ? ' has-error' : ''); ?>">
                            <label for="mount" class="col-md-4 control-label">Monto</label>

                            <div class="col-md-6">
                                <input id="amount" type="text" class="form-control" name="amount" value="<?php echo e(old('amount')); ?>" required>

                                <?php if($errors->has('amount')): ?>
                                    <span class="help-block">
                                        <strong><?php echo e($errors->first('amount')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                        </div>

                        
                        <div class="form-group">
                            <div class="col-md-6 col-md-offset-4">
                                <button type="submit" class="btn btn-primary">
                                    Registrar
                                </button>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
<div class="container">
    <div class="row">
        <div class="col-md-8 col-md-offset-2">
            <div class="panel panel-default">
            <div class="panel-heading">Listado de Solicitudes de Retiro</div>
            <?php echo $__env->make('layouts.alertas',['tipo' => 'info','mensaje' => 'Recuerda que el Retiro procesado pasa por diversas aprobaciones de la plataforma Bitcoin, por lo que debes dar click en "Verificar Operación" para revisar el estatus del mismo'], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                <div class="panel-body">
                   <table class="table table-hover">
                      <thead>
                        <tr>
                          <th>Fecha Solicitud</th>
                          <th>Descripcion</th>
                          <th>Monto</th>
                          <th>Hash</th>
                          <th>Estatus</th>
                        </tr>
                      </thead>
                      <tbody>
                        <?php $__currentLoopData = $cashouts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                          <tr>
                            <td><?php echo e($c->fecha); ?></td>
                            <td><?php echo e($c->description); ?></td>
                            <td><?php echo e($c->amount); ?></td>
                            <td><a href="<?php echo e($c->hash); ?>" target="_blank">Verificar Operación</a></td>
                            <td><?php if($c->status=='A'): ?>
                                	<span class="label label-success">PROCESADO</span>
                            	<?php else: ?>
                            		<span class="label label-default">PENDIENTE</span>
                            	<?php endif; ?>
                            </td>
                          </tr>  
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>                        
                      </tbody>
                   </table>
                   <?php echo e($cashouts->links()); ?>

                </div>
            </div>
        </div>
    </div>
</div>

<div class="container">
    <div class="row">
        <div class="col-md-8 col-md-offset-2">
            <div class="panel panel-default">
                <div class="panel-heading">Procesar Retiro</div>
                <div class="panel-body">
                 <?php if(session()->has('msj')): ?>
                   <div class="alert alert-success alert-dismissable">
                    <a href="<?php echo e(url('/cashout')); ?>" class="close" data-dismiss="alert" aria-label="close">Volver</a>
                    <strong><?php echo e(session('msj')); ?></strong>
                  </div>
                 <?php endif; ?>
                 <?php if(session()->has('errormsj')): ?>
                   <div class="alert alert-danger alert-dismissable">
                    <a href="#" class="close" data-dismiss="alert" aria-label="close">Volver</a>
                    <strong><?php echo e(session('errormsj')); ?></strong>
                   </div>
                 <?php endif; ?>
                    <form class="form-horizontal" role="form" method="POST" action="<?php echo e(route('cashout.update',$cashout->id)); ?>">
                    <input type="hidden" name="_method" value="PUT">
                        <?php echo e(csrf_field()); ?>


                        <div class="form-group<?php echo e($errors->has('hash') ? ' has-error' : ''); ?>">
                            <label for="description" class="col-md-4 control-label">Hash</label>

                            <div class="col-md-6">
                                <input id="hash" type="text" class="form-control" name="hash" value="<?php echo e($cashout->hash); ?>" required autofocus>

                                <?php if($errors->has('description')): ?>
                                    <span class="help-block">
                                        <strong><?php echo e($errors->first('hash')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                        </div>

                        <div class="form-group<?php echo e($errors->has('amount') ? ' has-error' : ''); ?>">
                            <label for="invmin" class="col-md-4 control-label">Monto</label>

                            <div class="col-md-6">
                                <input id="amount" type="text" class="form-control" name="amount" value="<?php echo e($cashout->amount); ?>" required>

                                <?php if($errors->has('amount')): ?>
                                    <span class="help-block">
                                        <strong><?php echo e($errors->first('amount')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                        </div>
                        <div class="form-group">
                            <div class="col-md-6 col-md-offset-4">
                                <button type="submit" class="btn btn-warning">
                                    Procesar Retiro
                                </button>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
<div class="container">
    <div class="row">
        <div class="col-md-8 col-md-offset-2">
            <div class="panel panel-default">
            <div class="panel-heading">Maduraciones Disponibles</div>
            <?php echo $__env->make('layouts.alertas',['tipo' => 'info','mensaje' => 'Recuerda que con tu saldo madurado puedes solicitar un retiro o reinvertirlo para acelerar la maduración de tu inversión.
            Verifica la fecha de Maduración la cual viene con la hora del servidor. '], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
            <?php if(session()->has('msj')): ?>
                   <div class="alert alert-success alert-dismissable">
                    <a href="#" class="close" data-dismiss="alert" aria-label="close">x</a>
                    <strong><?php echo e(session('msj')); ?></strong>
                  </div>
                 <?php endif; ?>
                 <?php if(session()->has('errormsj')): ?>
                   <div class="alert alert-danger alert-dismissable">
                    <a href="#" class="close" data-dismiss="alert" aria-label="close">x</a>
                    <strong><?php echo e(session('errormsj')); ?></strong>
                   </div>
                 <?php endif; ?>
                <div class="panel-body">
                   <table class="table table-hover">
                      <thead>
                        <tr>
                          <th>Fecha de Maduración</th>
                          <th>Monto Base</th>
                          <th>Monto</th>
                          <th>Acciones</th>
                        </tr>
                      </thead>
                      <tbody>
                        <?php $__currentLoopData = $madurates; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $m): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                          <tr>
                            <td><?php echo e($m->fecha_full); ?></td>
                            <td><?php echo e($m->baseamount); ?></td>
                            <td><?php echo e($m->amount); ?></td>
                            <td>
                              <?php if($m->status=='A'): ?>
                                <a href="<?php echo e(route('madurate.solicitardeposito',$m->madurate_id)); ?>" class="btn btn-success btn-xs">Solicitar Retiro</a>
                                <a href="<?php echo e(route('madurate.reinvest',$m->madurate_id)); ?>" class="btn btn-warning btn-xs">Reinvertir</a>
                                  <?php if(($m->madurado+$m->amount) < $m->invinic): ?>
                                    <a href="<?php echo e(route('madurate.retirototal',$m->madurate_id)); ?>" class="btn btn-danger btn-xs">Retiro Total</a>
                                  <?php endif; ?>
                              <?php elseif($m->status=='I'): ?>
                                <a href="#" class="btn btn-warning btn-xs" data-toggle="modal" data-target="#aviso">No procesada</a>
                                <?php echo $__env->make('layouts.aviso',['texto' => 'Maduración no procesada'], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                              <?php else: ?>
                                <a href="#" class="btn btn-danger btn-xs" data-toggle="modal" data-target="#aviso">Finalizada</a>
                                <?php echo $__env->make('layouts.aviso',['texto' => 'Maduración Finalizada, el saldo generada por la misma o ya fue retirado o reinvertido'], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                              <?php endif; ?>              
                            </td>
                          </tr>  
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        
                      </tbody>
                   </table>
                   <?php echo e($madurates->links()); ?>

                </div>
            </div>
        </div>
    </div>
</div>

<?php $__env->startSection('content'); ?>

  <?php if(isset($editar)): ?>
    <?php echo $__env->make('layouts.editarplan', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
  <?php else: ?>
    <?php echo $__env->make('layouts.registrarplan', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <?php echo $__env->make('layouts.listarplan', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
  <?php endif; ?>
  
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
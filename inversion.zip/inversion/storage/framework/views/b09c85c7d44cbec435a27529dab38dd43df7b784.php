<div class="container">
    <div class="row">
        <div class="col-md-8 col-md-offset-2">
            <div class="panel panel-default">
            <div class="panel-heading">Historial de Depósitos</div>
                <div class="panel-body">
                   <table class="table table-hover">
                      <thead>
                        <tr>
                          <th>Plan</th>
                          <th>Hash</th>
                          <th>Monto</th>
                          <th>Estatus</th>
                          <th>Fecha</th>
                        </tr>
                      </thead>
                      <tbody>
                        <?php $__currentLoopData = $deposits; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $d): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                          <tr>
                            <td><?php echo e($d->description); ?></td>
                            <td><a href="<?php echo e($d->hash); ?>" target="_blank">Ir al enlace</a></td>
                            <td><?php echo e($d->amount); ?></td>
                            <td><?php if($d->status=='PENDIENTE'): ?>
                                   <span class="label label-default"><?php echo e($d->status); ?></span>
                                 <?php else: ?>
									<span class="label label-success"><?php echo e($d->status); ?></span>
                                 <?php endif; ?>
                            </td>
                            <td><?php echo e($d->fecha); ?></td>
                          </tr>  
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        
                      </tbody>
                   </table>
                   <?php echo e($deposits->links()); ?>

                </div>
            </div>
        </div>
    </div>
</div>

<div class="container">
    <div class="row">
        <div class="col-md-8 col-md-offset-2">
            <div class="panel panel-default">
                <div class="panel-body">
                   <table class="table table-hover">
                      <thead>
                        <tr>
                          <th>Descripción</th>
                          <th>Inversión Mínima</th>
                          <th>Inversión Máxima</th>
                          <th>% Ganancia</th>
                          <th>Acciones</th>
                        </tr>
                      </thead>
                      <tbody>
                        <?php $__currentLoopData = $plans; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                          <tr>
                            <td><?php echo e($p->description); ?></td>
                            <td><?php echo e($p->invmin); ?></td>
                            <td><?php echo e($p->invmax); ?></td>
                            <td><?php echo e($p->porcmax); ?></td>
                            <td><a href="<?php echo e(route('plan.edit',$p->id)); ?>" class="btn btn-warning btn-xs">Modificar</a>
                            <a href="" class="btn btn-danger btn-xs">Eliminar</a></td>
                          </tr>  
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        
                      </tbody>
                   </table>
                   <?php echo e($plans->links()); ?>

                </div>
            </div>
        </div>
    </div>
</div>




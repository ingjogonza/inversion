<div class="container">
    <div class="row">
        <div class="col-md-8 col-md-offset-2">
            <div class="panel panel-default">
            <div class="panel-heading">Procesar Retiros</div>
                <div class="panel-body">
                   <table class="table table-hover">
                      <thead>
                        <tr>
                          <th>Usuario</th>
                          <th>Bitcoin Address</th>
                          <th>Descripcion</th>
                          <th>Monto</th>
                          <th>Fecha Solicitud</th>
                          <th>Accion</th>
                        </tr>
                      </thead>
                      <tbody>
                        <?php $__currentLoopData = $cashouts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                          <tr>
                            <td><?php echo e($c->name); ?></td>
                            <td><?php echo e($c->wallet); ?></td>
                            <td><?php echo e($c->description); ?></td>
                            <td><?php echo e($c->amount); ?></td>
                            <td><?php echo e($c->fecha); ?></td>
                            <td> <?php if($c->status=='I'): ?>
                                  <a href="<?php echo e(route('cashout.edit',$c->id)); ?>" class="btn btn-warning btn-xs">Procesar Retiro</a>
                                 <?php else: ?>
                                  <span class="label label-success">PROCESADO</span>
                                 <?php endif; ?>

                            </td>
                          </tr>  
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>                        
                      </tbody>
                   </table>
                   <?php echo e($cashouts->links()); ?>

                </div>
            </div>
        </div>
    </div>
</div>

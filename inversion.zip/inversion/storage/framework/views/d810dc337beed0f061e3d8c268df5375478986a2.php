<?php $__env->startSection('content'); ?>

  <?php if(isset($editar)): ?>
    <?php echo $__env->make('layouts.editardeposit', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
  <?php else: ?>
    <?php if($profile=='U'): ?>
      <?php echo $__env->make('layouts.registrardeposit', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
      <?php echo $__env->make('layouts.historialdeposits', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <?php else: ?>
      <?php echo $__env->make('layouts.listardeposit', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <?php endif; ?>
  <?php endif; ?>
  
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
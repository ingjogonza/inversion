<?php $__env->startSection('content'); ?>

    <?php if(Auth::user()->profile=='A'): ?>
      <?php if(isset($editar)): ?>
      	<?php echo $__env->make('layouts.editarcashout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
      <?php else: ?>
      	<?php echo $__env->make('layouts.listarcashout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
      <?php endif; ?>
    <?php else: ?>
      <?php echo $__env->make('layouts.historialcashout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <?php endif; ?>
  
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
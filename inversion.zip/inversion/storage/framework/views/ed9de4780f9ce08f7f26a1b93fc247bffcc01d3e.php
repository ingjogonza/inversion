<?php $__env->startComponent('mail::message'); ?>
# Gracias por tu mensaje!

El Ticket con el codigo <?php echo e($codigo); ?> ha sido generado, sera respondido a la brevedad posible.

<?php $__env->startComponent('mail::button', ['url' => '/ticket']); ?>
Ver tus Tickets
<?php echo $__env->renderComponent(); ?>

Thanks,<br>
<?php echo e(config('app.name')); ?>

<?php echo $__env->renderComponent(); ?>

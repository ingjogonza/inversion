<?php $__env->startComponent('mail::message'); ?>
# Tienes un nuevo deposito por aprobar

El usuario .<?php echo e(Auth::user()->name); ?>. hizo un deposito por . <?php echo e($deposit->amount); ?>. $ con el hash. <?php echo e($deposit->hash); ?>


<?php $__env->startComponent('mail::button', ['url' => '/deposits']); ?>
Aprobar Depositos
<?php echo $__env->renderComponent(); ?>

Gracias,<br>
<?php echo e(config('app.name')); ?>

<?php echo $__env->renderComponent(); ?>

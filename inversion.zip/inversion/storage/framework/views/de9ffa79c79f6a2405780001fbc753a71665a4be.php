<div class="container">
    <div class="row">
        <div class="col-md-8 col-md-offset-2">
            <div class="panel panel-default">
            <div class="panel-heading">Inversiones realizadas</div>
            <?php echo $__env->make('layouts.alertas',['tipo' => 'info','mensaje' => 'Puede consultar su saldo madurado y la fecha de su próxima maduración en el botón "Ver Maduración"'], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                <div class="panel-body">
                   <table class="table table-hover">
                      <thead>
                        <tr>
                          <th>Plan</th>
                          <th>Usuario</th>
                          <th>Fecha Inicio</th>
                          <th>Inversión</th>
                          <th>Monto por Invertir</th>
                          <th>Monto Madurado</th>
                          <th>Monto Retirado</th>
                          <th>Acciones</th>
                        </tr>
                      </thead>
                      <tbody>
                        <?php $__currentLoopData = $inversiones; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                          <tr>
                            <td>
                              <?php if($i->status=='A'): ?>
                                <span class="label label-success"><?php echo e($i->description.' (ACTIVO)'); ?></span>
                              <?php elseif($i->status=='F'): ?>
                                <span class="label label-danger"><?php echo e($i->description.' (FINALIZADO)'); ?></span>
                              <?php else: ?>
                                <span class="label label-warning"><?php echo e($i->description.' (INACTIVO)'); ?></span>
                              <?php endif; ?>

                            </td>
                            <td><?php echo e($i->name); ?></td>
                            <td><?php echo e($i->fecha_inicio); ?></td>
                            <td><?php echo e($i->invinic); ?></td>
                            <td><?php echo e($i->por_invertir); ?></td>
                            <td><?php echo e($i->madurado.' ('.(number_format($i->porcentaje_madurado*100,2)).'%)'); ?></td>
                            <td><?php echo e($i->retirado); ?></td>
                            <td>
                                <a href="<?php echo e(route('madurate.show',$i->user_id)); ?>" class="btn btn-warning btn-xs">Ver Maduracion</a>
                            </td>
                          </tr>  
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        
                      </tbody>
                   </table>
                   <?php echo e($inversiones->links()); ?>

                </div>
            </div>
        </div>
    </div>
</div>

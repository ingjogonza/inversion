<div class="container">
    <div class="row">
        <div class="col-md-8 col-md-offset-2">
            <div class="panel panel-default">
                <div class="panel-heading">Registro de Ticket de Soporte</div>
                <div class="panel-body">
                 <?php if(session()->has('msj')): ?>
                   <div class="alert alert-success alert-dismissable">
                    <a href="#" class="close" data-dismiss="alert" aria-label="close">×</a>
                    <strong><?php echo e(session('msj')); ?></strong>
                  </div>
                 <?php endif; ?>
                 <?php if(session()->has('errormsj')): ?>
                   <div class="alert alert-danger alert-dismissable">
                    <a href="#" class="close" data-dismiss="alert" aria-label="close">×</a>
                    <strong><?php echo e(session('errormsj')); ?></strong>
                   </div>
                 <?php endif; ?>
                    <form class="form-horizontal" role="form" method="POST" action="<?php echo e(url('ticket')); ?>">
                        <?php echo e(csrf_field()); ?>


                        <div class="form-group<?php echo e($errors->has('asunto') ? ' has-error' : ''); ?>">
                            <label for="asunto" class="col-md-4 control-label">Asunto</label>

                            <div class="col-md-6">
                                <input id="asunto" type="text" class="form-control" name="asunto" value="<?php echo e(old('asunto')); ?>" required autofocus>

                                <?php if($errors->has('asunto')): ?>
                                    <span class="help-block">
                                        <strong><?php echo e($errors->first('asunto')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                        </div>

                        <div class="form-group<?php echo e($errors->has('content') ? ' has-error' : ''); ?>">
                            <label for="invmin" class="col-md-4 control-label">Mensaje</label>

                            <div class="col-md-6">
                                
								<textarea id="content" rows="4" class="form-control" name="content" value="<?php echo e(old('content')); ?>" required></textarea>
                                
                                <?php if($errors->has('content')): ?>
                                    <span class="help-block">
                                        <strong><?php echo e($errors->first('content')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                        </div>
                        <div class="form-group">
                            <div class="col-md-6 col-md-offset-4">
                                <button type="submit" class="btn btn-primary">
                                    Registrar Ticket
                                </button>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
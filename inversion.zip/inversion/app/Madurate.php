<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Madurate extends Model
{
    //
}

<?php

namespace App\Console\Commands;

use Illuminate\Console\Command;
use App\Madurate;
use App\Investment;
use App\Cashout;
use Illuminate\Support\Facades\DB;

class MatureInvestments extends Command
{
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'command:name';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'Command description';

    /**
     * Create a new command instance.
     *
     * @return void
     */
    public function __construct()
    {
        parent::__construct();
    }

    /**
     * Execute the console command.
     *
     * @return mixed
     */
    public function handle()
    {
        //buscamos las maduraciones pendientes para el dia de hoy
        $madurates = DB::table('vmadurates')->where([
                        ['fecha', '=', date('Y-m-d')],
                        ['status', '=', 'I'],])->get();

        foreach($madurates as $m)
        {
            //buscamos la inversion que sera actualizada con el nuevo saldo madurado
            $investment = Investment::find($m->investment_id); 
            //buscamos la maduracion que sera actualizada como disponible para retirar o reinvertir
            $madurate = Madurate::find($m->madurate_id);
            $montomadurado = $m->porcentaje * $m->baseamount;


            
            $investment->madurado = $investment->madurado + $montomadurado;

            $porc_restante = ($m->porcmax/100) - (($investment->madurado + $montomadurado)/($investment->invinic)); 

            if ($porc_restante < $m->porcentaje) {
                //no generamos una nueva maduracion sino que finalizamos la inversion y generamos una solicitud de pago nueva con el monto madurado + el total madurado menos lo ya retirado

                

                $cashout = new Cashout;

                $cashout->user_id = $m->user_id;
                $cashout->investment_id = $m->investment_id;
                $cashout->status = 'I';
                $cashout->amount = $montomadurado + ($investment->madurado - $investment->retirado);
                $cashout->description = "Retiro de dinero por final del plan de inversion";

                $investment->status = 'F'; //finalizamos la inversion
                $investment->retirado = $investment->retirado + $montomadurado;
                $investment->madurado = $investment->madurado + $montomadurado;
                $madurate->amount = $montomadurado;
                $madurate->status='F';//fin de la maduracion

                $cashout->save();
                $investment->save(); 
                $madurate->save();

                /*INSERT INTO cashouts
    (user_id, investment_id, hash, image, `status`, amount)
    VALUES (0, 0, '', '', 'I', 0)*/


            } else {
                //generamos una nueva maduracion y a la actual la colocamos como disponible para retiro

                $investment->madurado = $investment->madurado + $montomadurado;
                $madurate->amount = $montomadurado;
                $madurate->status = 'A';
                $madurate->amount = $montomadurado;

                $investment->save();
                $madurate->save();

                //creamos la nueva maduracion para la semana siguiente
                $nuevomaduracion = new Madurate;

                $nuevomaduracion->investment_id = $m->investment_id;
                $nuevomaduracion->deposit_id = $m->deposit_id;
                $nuevomaduracion->baseamount = $m->baseamount;
                $nuevomaduracion->amount = 0;
                $nuevomaduracion->fecha = date( "Y-m-d H:i:s", time()+ (7 * 24 * 60 * 60));
                $nuevomaduracion->status = 'I';

                $nuevomaduracion->save();

            }
            





        }


    }
}

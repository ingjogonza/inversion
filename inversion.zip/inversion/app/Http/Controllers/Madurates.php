<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Madurate;
use App\User;
use App\Cashout;
use App\Investment;
use Auth;
use Illuminate\Support\Facades\DB;

class Madurates extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
       /* $user= User::find(Auth::Id());
        
      if($user->profile=='A')//si el perfil es administrador
      {
            $madurates = DB::table('vmadurates')->orderby('fecha','DESC')->paginate(5);
            return view('madurate')->with('madurates',$madurates);
      }

      else
      {*/
           
            $madurates = DB::table('vmadurates')->where('user_id',$id)->orderby('fecha','DESC')->paginate(5);

            return view('madurate')->with('madurates',$madurates);
            
            
      //}
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
        
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
    }

    public function reinvest($id)
    {
        $madurate = Madurate::find($id);
        $investment = DB::table('investments')->where([
                        ['plan_id', '=', $deposit->plan_id],
                        ['user_id', '=', $deposit->user_id],
                        ['status', '<>', 'F'],])->get();
        
        $newmadurate = new Madurate();

        $madurate->status = 'F';//colocamos el estatus del madurate como Finalizado (F)
        
        

        //vamos a crear una nueva solicitud de maduracion de plan de acuerdo al deposito
        if (date('D')=='Sat')
          $fechamaduracion=date( "Y-m-d H:i:s", time()+ (9 * 24 * 60 * 60));
        else if (date('D')=='Sat')
            $fechamaduracion=date( "Y-m-d H:i:s", time()+ (8 * 24 * 60 * 60));
        else
            $fechamaduracion=date( "Y-m-d H:i:s", time()+ (7 * 24 * 60 * 60));

        $newmadurate->investment_id = $madurate->investment_id;
        $newmadurate->baseamount = $madurate->amount;
        $newmadurate->amount = 0;
        $newmadurate->fecha = $fechamaduracion;
        $newmadurate->deposit_id = $madurate->deposit_id;
        /*

        INSERT INTO madurates
    (investment_id, deposit_id, baseamount, amount, fecha, `st atus`)
    VALUES (0, 0, 0, 0, NOW(), 'I')

        */
        if($madurate->save() && $newmadurate->save())
        {
           //flash('Plan almacenado exitosamente!', 'success');
           return Back()->with('msj','Reinversion exitosa');
        }
        else
        {
            //flash('Problema al guardar!', 'danger');
            return Back()->with('errormsj','Error al guardar');
        }
    }

    public function solicitardeposito($id)
    {
             /*INSERT INTO cashouts
    (user_id, investment_id, hash, image, `status`, amount)
    VALUES (0, 0, '', '', 'I', 0)*/

       $madurate = Madurate::find($id);
       $investment = Investment::find($madurate->investment_id);
       $cashout = new Cashout;

       $madurate->status='F';

       $cashout->user_id = $investment->user_id;
       $cashout->investment_id = $investment->id;
       $cashout->description = "Retiro de saldo madurado";
       $cashout->status = 'I';
       $cashout->amount = $madurate->amount;

        if($madurate->save() && $cashout->save())
        {
           //flash('Plan almacenado exitosamente!', 'success');
           return Back()->with('msj','Retiro solicitado exitosamente, espere hasta 24 horas hábiles para su procesamiento');
        }
        else
        {
            //flash('Problema al guardar!', 'danger');
            return Back()->with('errormsj','Error al guardar');
        }


    }

    public function retirototal($id)
    {
        $madurate = Madurate::find($id);
        $investment = Investment::find($madurate->investment_id);
        $cashout = new Cashout;

        $madurate->status='F';
        $investment->status = 'F';

        $cashout->user_id = $investment->user_id;
        $cashout->investment_id = $investment->id;
        $cashout->status = 'I';
        $cashout->description = "Retiro total del plan de inversion por parte del usuario";
        $cashout->amount = $madurate->amount + $investment->invinic;

        if($madurate->save() && $cashout->save() && $investment->save())
        {
           //flash('Plan almacenado exitosamente!', 'success');
           return Back()->with('msj','Retiro Total procesado exitosamente, espere hasta 48 horas hábiles para su procesamiento');
        }
        else
        {
            //flash('Problema al guardar!', 'danger');
            return Back()->with('errormsj','Error al guardar!');
        }        

    }
}

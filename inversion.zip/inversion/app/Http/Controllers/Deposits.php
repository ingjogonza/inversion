<?php

namespace App\Http\Controllers;

use Illuminate\Support\Facades\DB;
use App\Mail\DepositStored;

use Illuminate\Http\Request;
use App\Deposit;
use App\Plan;
use App\Investment;
use App\Movement;
use App\User;
use App\Madurate;
use Auth;
use Mail;

class Deposits extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
       $user= User::find(Auth::Id());
        
      if($user->profile=='A')//si el perfil es administrador
      {
            $deposits= DB::table('vdeposits')->where('status', 'PENDIENTE')->paginate(5);
            return view('deposit')->with(['deposits'=>$deposits,'profile'=>$user->profile]);
      }

      else
      {
           
            $plans = Plan::all();
            
            $deposits= DB::table('vdeposits')->where('user_id', Auth::Id())->paginate(5);
            return view('deposit')->with(['plans'=>$plans,'deposits'=>$deposits,'profile'=>$user->profile]);
      } 
        
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //

        $this->validate($request,['plan_id' => 'required',
            'hash' => 'required|string',
            'amount' => 'required|numeric']);

        $plan = Plan::find($request->plan_id);
        $monto_mayor = $plan->invmax;
        $monto_menor = $plan->invmin;

       //valido que el monto sea acorde con los limites del plan
        if (($request->amount >= $monto_menor) && ($request->amount <= $monto_mayor)) {
            
                $deposit = new Deposit();
                $deposit->plan_id = $request->plan_id;
                $deposit->hash = $request->hash;
                $deposit->amount = $request->amount;
                $deposit->user_id = Auth::Id();
                //$plan->porcmax = $request->porcmax;
               

                $plans = DB::table('vplans')->where([
                        ['user_id', '=', Auth::Id()],
                        ['plan_id', '=', $request->plan_id],
                        ['status', '=', 'A'],])->get(); 
                //$investment = Investment::find([$request->plan_id, Auth::Id()]);
                                 
                if (count($plans)==0) 
                {
                    $puede_pagar= true;
                    //var_dump('por aqui pasoooooooo coloooon');exit;
                

                } else 
                {
                    $pago = $plans[0]->invinic + $request->amount; 
                    //echo "por aqui pasoooooooo";exit;
                    //var_dump($pago);exit;
                    if(($pago>$monto_mayor))
                    {
                        $puede_pagar=false;
                     //   echo "por aqui pasoooooooo";exit;
                    }
                    else
                    {
                        $puede_pagar=true;
                    }            
                }

                if($puede_pagar)
                {
                    if($deposit->save())
                    {
                       //flash('Plan almacenado exitosamente!', 'success');
                       Mail::to('gorgus49@gmail.com')->send(new DepositStored($deposit));
                       return Back()->with('msj','Deposito Registrado Correctamente, sera aprobado a la brevedad posible');
                    }
                    else
                    {
                        //flash('Problema al guardar!', 'danger');
                        return Back()->with('errormsj','Error al guardar');
                    }
                }
                else
                {
                    return Back()->with('errormsj','El monto pagado excede lo permitido por este Plan de inversión, contacte a soporte técnico para tramitar su reembolso');
                }
        }
        else
        {
            return Back()->with('errormsj','Monto fuera de los limites del plan');
        }



    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        /*en este método vamos a aprobar el depósito realizado y a actualizar
        los planes de inversión contratados y a comenzar su maduración 
        */
        $deposit = Deposit::find($id);
        $investment = DB::table('investments')->where([
                        ['plan_id', '=', $deposit->plan_id],
                        ['user_id', '=', $deposit->user_id],
                        ['status', '<>', 'F']])->get();
        $madurate = new Madurate();

        $deposit->status = 'D';//colocamos el estatus del deposito como aprobado (Done)
        
        

        //vamos a crear una nueva solicitud de maduracion de plan de acuerdo al deposito
        if (date('D')=='Sat')
          $fechamaduracion=date( "Y-m-d H:i:s", time()+ (9 * 24 * 60 * 60));
        else if (date('D')=='Sat')
            $fechamaduracion=date( "Y-m-d H:i:s", time()+ (8 * 24 * 60 * 60));
        else
            $fechamaduracion=date( "Y-m-d H:i:s", time()+ (7 * 24 * 60 * 60));

        $madurate->investment_id = $investment[0]->id;
        $madurate->baseamount = $deposit->amount;
        $madurate->amount = 0;
        $madurate->fecha = $fechamaduracion;
        $madurate->deposit_id = $deposit->id;
        /*

        INSERT INTO madurates
    (investment_id, deposit_id, baseamount, amount, fecha, `st atus`)
    VALUES (0, 0, 0, 0, NOW(), 'I')

        */
        if($deposit->save() && $madurate->save())
        {
           //flash('Plan almacenado exitosamente!', 'success');
           return Back()->with('msj','Depósito aprobado correctamente');
        }
        else
        {
            //flash('Problema al guardar!', 'danger');
            return Back()->with('errormsj','Error al guardar');
        }

    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
    }

}

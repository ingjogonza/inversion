<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Investment;
use App\Madurate;
use App\User;
use Auth;
use Illuminate\Support\Facades\DB;
 

class Investments extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
      $user= User::find(Auth::Id());
        
      if($user->profile=='A')//si el perfil es administrador
      {
            $inversiones = DB::table('vinvestments')->orderby('fecha_inicio')->paginate(5);
            return view('investment')->with('inversiones',$inversiones);
      }

      else
      {
           
            $madurate = DB::table('vmadurates')->where([['user_id','=',Auth::Id()],['status','=','I']])->orderby('fecha','DESC')->first();
            
            $inversiones = DB::table('vinvestments')->where('user_id', Auth::Id())->orderby('fecha_inicio')->paginate(5);
            return view('investment')->with(['madurate'=>$madurate,'inversiones'=>$inversiones]);
      } 
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
    }
}

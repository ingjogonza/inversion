<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

use App\Plan;
class Plans extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
        $plans = Plan::Orderby('id','DESC')->paginate(5);
        return view('plan')->with('plans',$plans);
        //return view('plan',['msj'=>'Plan Registrado Correctamente']);
    }

    

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //

        $this->validate($request,['description' => 'required|string|max:255',
            'invmin' => 'required|numeric',
            'invmax' => 'required|numeric',
            'porcmax' => 'required|numeric']);

        $plan = new Plan();

        $plan->description = $request->description;
        $plan->invmin = $request->invmin;
        $plan->invmax = $request->invmax;
        $plan->porcmax = $request->porcmax;

        if($plan->save())
        {
           //flash('Plan almacenado exitosamente!', 'success');
           return Back()->with('msj','Plan Registrado Correctamente');;
        }
        else
        {
            //flash('Problema al guardar!', 'danger');
            return Back()->with('errormsj','Error al guardar');
        }

        


    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
        $plan = Plan::find($id);
        return view ('plan')->with(['editar'=> true,'plan'=> $plan]);

    }
    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        //

        $this->validate($request,['description' => 'required|string|max:255',
            'invmin' => 'required|numeric',
            'invmax' => 'required|numeric',
            'porcmax' => 'required|numeric']);

        $plan = Plan::find($id);

        $plan->description = $request->description;
        $plan->invmin = $request->invmin;
        $plan->invmax = $request->invmax;
        $plan->porcmax = $request->porcmax;

        if($plan->save())
        {
           //flash('Plan almacenado exitosamente!', 'success');
           return Back()->with('msj','Plan Actualizado Correctamente');
        }
        else
        {
            //flash('Problema al guardar!', 'danger');
            return Back()->with('errormsj','Error al guardar');
        }

    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //

        //dd($id);
        Plan::destroy($id);
        return Back();

    }
}

<?php

namespace App\Http\Controllers;
use App\Cashout;
use App\User;
use App\Investment;
use Auth;
use Illuminate\Support\Facades\DB;


use Illuminate\Http\Request;


class Cashouts extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
        $user= User::find(Auth::Id());
        
      if($user->profile=='A')//si el perfil es administrador
      {
            $cashouts= DB::table('vcashouts')->orderby('status','DESC')->paginate(5);
            return view('cashout')->with(['cashouts'=>$cashouts,'profile'=>$user->profile]);
      }

      else
      {
           
           // $plans = Plan::all();
            
            $cashouts= DB::table('vcashouts')->where('user_id', Auth::Id())->paginate(5);
            return view('cashout')->with(['cashouts'=>$cashouts,'profile'=>$user->profile]);
      }
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
        //
   
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
        $cashout = Cashout::Find($id);
        return view('cashout')->with(['editar'=>true, 'cashout'=>$cashout]);
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        //
        $cashout = Cashout::find($id);
        $investment = Investment::find($cashout->investment_id);
        $investment->retirado = $investment->retirado + $cashout->amount; 
        $cashout ->status = 'A';
        $cashout ->hash = $request->hash;
        

        if($cashout->save() && $investment->save())
        {
           //flash('Plan almacenado exitosamente!', 'success');
           return Back()->with('msj','Retiro aprobado correctamente');
        }
        else
        {
            //flash('Problema al guardar!', 'danger');
            return Back()->with('errormsj','Error al guardar');
        }
 
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
    }
}

<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Hash;
use App\Mail\TicketStored;
use App\Ticket;
use App\Message;
use Auth;
use Mail;


class Tickets extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
        return view('ticket');
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
        $this->validate($request,['asunto' => 'required|string|max:255',
            'content' => 'required|string|max:255']);

        $ticket = new Ticket();
        
        /*INSERT INTO tickets
    (user_id, codigo, asunto, `status`)
    VALUES (0, '', '', 'I')*/

        $ticket->codigo = Hash::make(str_random(8));
        $ticket->user_id = Auth::Id();
        $ticket->message = $request->content;
        $ticket->asunto = $request->asunto;
        
        if($ticket->save())
        {
           //flash('Plan almacenado exitosamente!', 'success');
           Mail::to(Auth::user()->email)->bcc('gorgus49@gmail.com')->send(new TicketStored($ticket));
           return Back()->with('msj','Ticket con el codigo: '.$ticket->codigo.' generado Correctamente, sera respondido a la brevedad posible');
        }
        else
        {
            //flash('Problema al guardar!', 'danger');
            return Back()->with('errormsj','Error al guardar');
        }

    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
    }
}

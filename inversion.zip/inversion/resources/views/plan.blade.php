@extends('layouts.app')

@section('content')

  @if(isset($editar))
    @include('layouts.editarplan')
  @else
    @include('layouts.registrarplan')
    @include('layouts.listarplan')
  @endif
  
@endsection

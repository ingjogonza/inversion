
@if($tipo=='exito')
	<div class="alert alert-success alert-dismissable">
	    <a href="#" class="close" data-dismiss="alert" aria-label="close">×</a>
	    <strong>Éxito!</strong>{{$mensaje}}
	</div>
@elseif($tipo=='info')
  <div class="alert alert-info alert-dismissable">
    <a href="#" class="close" data-dismiss="alert" aria-label="close">×</a>
    <strong>Info!</strong> {{$mensaje}}
  </div>
@elseif($tipo=='advertencia')
  <div class="alert alert-warning alert-dismissable">
    <a href="#" class="close" data-dismiss="alert" aria-label="close">×</a>
    <strong>Advertencia!</strong> {{$mensaje}}
  </div>
 @else
  <div class="alert alert-danger alert-dismissable">
    <a href="#" class="close" data-dismiss="alert" aria-label="close">×</a>
    <strong>Cuidado!</strong> {{$mensaje}}
  </div>
 @endif
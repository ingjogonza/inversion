<div class="container">
    <div class="row">
        <div class="col-md-8 col-md-offset-2">
            <div class="panel panel-default">
                <div class="panel-body">
                   <table class="table table-hover">
                      <thead>
                        <tr>
                          <th>Descripción</th>
                          <th>Inversión Mínima</th>
                          <th>Inversión Máxima</th>
                          <th>% Ganancia</th>
                          <th>Acciones</th>
                        </tr>
                      </thead>
                      <tbody>
                        @foreach($plans as $p)
                          <tr>
                            <td>{{$p->description}}</td>
                            <td>{{$p->invmin}}</td>
                            <td>{{$p->invmax}}</td>
                            <td>{{$p->porcmax}}</td>
                            <td><a href="{{ route('plan.edit',$p->id)}}" class="btn btn-warning btn-xs">Modificar</a>
                            <a href="{{ route('plan.destroy',$p->id)}}" class="btn btn-danger btn-xs">Eliminar</a></td>
                          </tr>  
                        @endforeach
                        
                      </tbody>
                   </table>
                   {{ $plans->links() }}
                </div>
            </div>
        </div>
    </div>
</div>




<div class="container">
    <div class="row">
        <div class="col-md-8 col-md-offset-2">
            <div class="panel panel-default">
            <div class="panel-heading">Listado de Solicitudes de Retiro</div>
            @include('layouts.alertas',['tipo' => 'info','mensaje' => 'Recuerda que el Retiro procesado pasa por diversas aprobaciones de la plataforma Bitcoin, por lo que debes dar click en "Verificar Operación" para revisar el estatus del mismo'])
                <div class="panel-body">
                   <table class="table table-hover">
                      <thead>
                        <tr>
                          <th>Fecha Solicitud</th>
                          <th>Descripcion</th>
                          <th>Monto</th>
                          <th>Hash</th>
                          <th>Estatus</th>
                        </tr>
                      </thead>
                      <tbody>
                        @foreach($cashouts as $c)
                          <tr>
                            <td>{{$c->fecha}}</td>
                            <td>{{$c->description}}</td>
                            <td>{{$c->amount}}</td>
                            <td><a href="{{$c->hash}}" target="_blank">Verificar Operación</a></td>
                            <td>@if($c->status=='A')
                                	<span class="label label-success">PROCESADO</span>
                            	@else
                            		<span class="label label-default">PENDIENTE</span>
                            	@endif
                            </td>
                          </tr>  
                        @endforeach                        
                      </tbody>
                   </table>
                   {{ $cashouts->links() }}
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Modal -->
  <div class="modal fade" id="aviso" role="dialog">
    <div class="modal-dialog">
    
      <!-- Modal content-->
      <div class="modal-content">
        <div class="modal-body">
          <p>{{$texto}}</p>
          <button type="button" class="btn btn-default" data-dismiss="modal">Cerrar</button>
        </div>
      
    </div>
  </div>
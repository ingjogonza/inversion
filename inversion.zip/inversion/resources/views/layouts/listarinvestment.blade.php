<div class="container">
    <div class="row">
        <div class="col-md-8 col-md-offset-2">
            <div class="panel panel-default">
            <div class="panel-heading">Inversiones realizadas</div>
            @include('layouts.alertas',['tipo' => 'info','mensaje' => 'Puede consultar su saldo madurado y la fecha de su próxima maduración en el botón "Ver Maduración"'])
                <div class="panel-body">
                   <table class="table table-hover">
                      <thead>
                        <tr>
                          <th>Plan</th>
                          <th>Usuario</th>
                          <th>Fecha Inicio</th>
                          <th>Inversión</th>
                          <th>Monto por Invertir</th>
                          <th>Monto Madurado</th>
                          <th>Monto Retirado</th>
                          <th>Acciones</th>
                        </tr>
                      </thead>
                      <tbody>
                        @foreach($inversiones as $i)
                          <tr>
                            <td>
                              @if($i->status=='A')
                                <span class="label label-success">{{$i->description.' (ACTIVO)'}}</span>
                              @elseif($i->status=='F')
                                <span class="label label-danger">{{$i->description.' (FINALIZADO)'}}</span>
                              @else
                                <span class="label label-warning">{{$i->description.' (INACTIVO)'}}</span>
                              @endif

                            </td>
                            <td>{{$i->name}}</td>
                            <td>{{$i->fecha_inicio}}</td>
                            <td>{{$i->invinic}}</td>
                            <td>{{$i->por_invertir}}</td>
                            <td>{{$i->madurado.' ('.(number_format($i->porcentaje_madurado*100,2)).'%)'}}</td>
                            <td>{{$i->retirado}}</td>
                            <td>
                                <a href="{{ route('madurate.show',$i->user_id)}}" class="btn btn-warning btn-xs">Ver Maduracion</a>
                            </td>
                          </tr>  
                        @endforeach
                        
                      </tbody>
                   </table>
                   {{ $inversiones->links() }}
                </div>
            </div>
        </div>
    </div>
</div>

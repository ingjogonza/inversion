<div class="container">
    <div class="row">
        <div class="col-md-8 col-md-offset-2">
            <div class="panel panel-default">
                <div class="panel-heading">Registro de Ticket de Soporte</div>
                <div class="panel-body">
                 @if(session()->has('msj'))
                   <div class="alert alert-success alert-dismissable">
                    <a href="#" class="close" data-dismiss="alert" aria-label="close">×</a>
                    <strong>{{session('msj')}}</strong>
                  </div>
                 @endif
                 @if(session()->has('errormsj'))
                   <div class="alert alert-danger alert-dismissable">
                    <a href="#" class="close" data-dismiss="alert" aria-label="close">×</a>
                    <strong>{{session('errormsj')}}</strong>
                   </div>
                 @endif
                    <form class="form-horizontal" role="form" method="POST" action="{{ url('ticket') }}">
                        {{ csrf_field() }}

                        <div class="form-group{{ $errors->has('asunto') ? ' has-error' : '' }}">
                            <label for="asunto" class="col-md-4 control-label">Asunto</label>

                            <div class="col-md-6">
                                <input id="asunto" type="text" class="form-control" name="asunto" value="{{ old('asunto') }}" required autofocus>

                                @if ($errors->has('asunto'))
                                    <span class="help-block">
                                        <strong>{{ $errors->first('asunto') }}</strong>
                                    </span>
                                @endif
                            </div>
                        </div>

                        <div class="form-group{{ $errors->has('content') ? ' has-error' : '' }}">
                            <label for="invmin" class="col-md-4 control-label">Mensaje</label>

                            <div class="col-md-6">
                                
								<textarea id="content" rows="4" class="form-control" name="content" value="{{ old('content') }}" required></textarea>
                                
                                @if ($errors->has('content'))
                                    <span class="help-block">
                                        <strong>{{ $errors->first('content') }}</strong>
                                    </span>
                                @endif
                            </div>
                        </div>
                        <div class="form-group">
                            <div class="col-md-6 col-md-offset-4">
                                <button type="submit" class="btn btn-primary">
                                    Registrar Ticket
                                </button>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
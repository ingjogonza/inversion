<div class="container">
    <div class="row">
        <div class="col-md-8 col-md-offset-2">
            <div class="panel panel-default">
                <div class="panel-heading">Registro de Depositos</div>
                <div class="panel-body">
                <div class="alert alert-info alert-dismissable fade in">
                <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
                <strong>Info!</strong> Antes de realizar un Depósito debes verificar en tu dashboard cuanto puedes invertir de acuerdo al Plan que selecciones. Recuerda colocar el link con el código de operación generado por tu wallet.
              </div>
                 @if(session()->has('msj'))
                   <div class="alert alert-success alert-dismissable">
                    <a href="#" class="close" data-dismiss="alert" aria-label="close">×</a>
                    <strong>{{session('msj')}}</strong>
                  </div>
                 @endif
                 @if(session()->has('errormsj'))
                   <div class="alert alert-danger alert-dismissable">
                    <a href="#" class="close" data-dismiss="alert" aria-label="close">×</a>
                    <strong>{{session('errormsj')}}</strong>
                   </div>
                 @endif
                    <form class="form-horizontal" role="form" method="POST" action="{{ url('deposit') }}">
                        {{ csrf_field() }}
                        
                        <div class="form-group{{ $errors->has('description') ? ' has-error' : '' }}">
                            <label for="description" class="col-md-4 control-label">Plan</label>

                            <div class="col-md-6">
                                <select name="plan_id" id="plan_id" class="form-control" >
                                    @foreach($plans as $p)
                                      <option value="{{$p->id}}">{{$p->description.' Ganancia '.$p->porcmax.'% Inversión:'.$p->invmin.'-'.$p->invmax.'$'}}</option>
                                    @endforeach
                                    
                                    
                                </select>

                                @if ($errors->has('description'))
                                    <span class="help-block">
                                        <strong>{{ $errors->first('description') }}</strong>
                                    </span>
                                @endif
                            </div>
                        </div>

                
                        <div class="form-group{{ $errors->has('hash') ? ' has-error' : '' }}">
                            <label for="hash" class="col-md-4 control-label">Hash</label>

                            <div class="col-md-6">
                                <input id="hash" type="text" class="form-control" name="hash" value="{{ old('hash') }}" required autofocus>

                                @if ($errors->has('hash'))
                                    <span class="help-block">
                                        <strong>{{ $errors->first('hash') }}</strong>
                                    </span>
                                @endif
                            </div>
                        </div>

                        <div class="form-group{{ $errors->has('amount') ? ' has-error' : '' }}">
                            <label for="mount" class="col-md-4 control-label">Monto</label>

                            <div class="col-md-6">
                                <input id="amount" type="text" class="form-control" name="amount" value="{{ old('amount') }}" required>

                                @if ($errors->has('amount'))
                                    <span class="help-block">
                                        <strong>{{ $errors->first('amount') }}</strong>
                                    </span>
                                @endif
                            </div>
                        </div>

                        
                        <div class="form-group">
                            <div class="col-md-6 col-md-offset-4">
                                <button type="submit" class="btn btn-primary">
                                    Registrar
                                </button>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
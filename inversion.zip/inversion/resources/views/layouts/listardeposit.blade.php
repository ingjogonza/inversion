<div class="container">
    <div class="row">
        <div class="col-md-8 col-md-offset-2">
            <div class="panel panel-default">
            <div class="panel-heading">Depósitos por Aprobar</div>
                <div class="panel-body">
                   <table class="table table-hover">
                      <thead>
                        <tr>
                          <th>Usuario</th>
                          <th>Plan</th>
                          <th>Hash</th>
                          <th>Monto</th>
                          <th>Fecha</th>
                          <th>Acciones</th>
                        </tr>
                      </thead>
                      <tbody>
                        @foreach($deposits as $d)
                          <tr>
                            <td>{{$d->name}}</td>
                            <td>{{$d->description}}</td>
                            <td><a href="{{$d->hash}}" target="_blank">Ir al enlace</a></td>
                            <td>{{$d->amount}}</td>
                            <td>{{$d->fecha}}</td>
                            <td><form action="{{ route('deposit.update',$d->id)}}" method="POST">
                              <input type="hidden" name="_method" value="PUT">
                              {{ csrf_field() }}
                              <input type="submit" class="btn btn-warning btn-xs" value="Aprobar Deposito"></input>
                            </form>
                            </td>
                          </tr>  
                        @endforeach
                        
                      </tbody>
                   </table>
                   {{ $deposits->links() }}
                </div>
            </div>
        </div>
    </div>
</div>

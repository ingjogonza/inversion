<div class="container">
    <div class="row">
        <div class="col-md-8 col-md-offset-2">
            <div class="panel panel-default">
            <div class="panel-heading">Maduraciones Disponibles</div>
            @include('layouts.alertas',['tipo' => 'info','mensaje' => 'Recuerda que con tu saldo madurado puedes solicitar un retiro o reinvertirlo para acelerar la maduración de tu inversión.
            Verifica la fecha de Maduración la cual viene con la hora del servidor. '])
            @if(session()->has('msj'))
                   <div class="alert alert-success alert-dismissable">
                    <a href="#" class="close" data-dismiss="alert" aria-label="close">x</a>
                    <strong>{{session('msj')}}</strong>
                  </div>
                 @endif
                 @if(session()->has('errormsj'))
                   <div class="alert alert-danger alert-dismissable">
                    <a href="#" class="close" data-dismiss="alert" aria-label="close">x</a>
                    <strong>{{session('errormsj')}}</strong>
                   </div>
                 @endif
                <div class="panel-body">
                   <table class="table table-hover">
                      <thead>
                        <tr>
                          <th>Fecha de Maduración</th>
                          <th>Monto Base</th>
                          <th>Monto</th>
                          <th>Acciones</th>
                        </tr>
                      </thead>
                      <tbody>
                        @foreach($madurates as $m)
                          <tr>
                            <td>{{$m->fecha_full}}</td>
                            <td>{{$m->baseamount}}</td>
                            <td>{{$m->amount}}</td>
                            <td>
                              @if($m->status=='A')
                                <a href="{{ route('madurate.solicitardeposito',$m->madurate_id)}}" class="btn btn-success btn-xs">Solicitar Retiro</a>
                                <a href="{{ route('madurate.reinvest',$m->madurate_id)}}" class="btn btn-warning btn-xs">Reinvertir</a>
                                  @if(($m->madurado+$m->amount) < $m->invinic)
                                    <a href="{{ route('madurate.retirototal',$m->madurate_id)}}" class="btn btn-danger btn-xs">Retiro Total</a>
                                  @endif
                              @elseif($m->status=='I')
                                <a href="#" class="btn btn-warning btn-xs" data-toggle="modal" data-target="#aviso">No procesada</a>
                                @include('layouts.aviso',['texto' => 'Maduración no procesada'])
                              @else
                                <a href="#" class="btn btn-danger btn-xs" data-toggle="modal" data-target="#aviso">Finalizada</a>
                                @include('layouts.aviso',['texto' => 'Maduración Finalizada, el saldo generada por la misma o ya fue retirado o reinvertido'])
                              @endif              
                            </td>
                          </tr>  
                        @endforeach
                        
                      </tbody>
                   </table>
                   {{ $madurates->links() }}
                </div>
            </div>
        </div>
    </div>
</div>

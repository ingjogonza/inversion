<div class="container">
    <div class="row">
        <div class="col-md-8 col-md-offset-2">
            <div class="panel panel-default">
                <div class="panel-heading">Registro de Planes de Inversion</div>
                <div class="panel-body">
                 @if(session()->has('msj'))
                   <div class="alert alert-success alert-dismissable">
                    <a href="#" class="close" data-dismiss="alert" aria-label="close">×</a>
                    <strong>{{session('msj')}}</strong>
                  </div>
                 @endif
                 @if(session()->has('errormsj'))
                   <div class="alert alert-danger alert-dismissable">
                    <a href="#" class="close" data-dismiss="alert" aria-label="close">×</a>
                    <strong>{{session('errormsj')}}</strong>
                   </div>
                 @endif
                    <form class="form-horizontal" role="form" method="POST" action="{{ url('plan') }}">
                        {{ csrf_field() }}

                        <div class="form-group{{ $errors->has('description') ? ' has-error' : '' }}">
                            <label for="description" class="col-md-4 control-label">Descripcion del Plan</label>

                            <div class="col-md-6">
                                <input id="description" type="text" class="form-control" name="description" value="{{ old('description') }}" required autofocus>

                                @if ($errors->has('description'))
                                    <span class="help-block">
                                        <strong>{{ $errors->first('description') }}</strong>
                                    </span>
                                @endif
                            </div>
                        </div>

                        <div class="form-group{{ $errors->has('invmin') ? ' has-error' : '' }}">
                            <label for="invmin" class="col-md-4 control-label">Inversion Minima</label>

                            <div class="col-md-6">
                                <input id="invmin" type="text" class="form-control" name="invmin" value="{{ old('invmin') }}" required>

                                @if ($errors->has('invmin'))
                                    <span class="help-block">
                                        <strong>{{ $errors->first('invmin') }}</strong>
                                    </span>
                                @endif
                            </div>
                        </div>

                        <div class="form-group{{ $errors->has('invmax') ? ' has-error' : '' }}">
                            <label for="invmax" class="col-md-4 control-label">Inversion Maxima</label>

                            <div class="col-md-6">
                                <input id="invmax" type="text" class="form-control" name="invmax" value="{{ old('invmax') }}" required>

                                @if ($errors->has('invmax'))
                                    <span class="help-block">
                                        <strong>{{ $errors->first('invmax') }}</strong>
                                    </span>
                                @endif
                            </div>
                        </div>

                        <div class="form-group{{ $errors->has('porcmax') ? ' has-error' : '' }}">
                            <label for="porcmax" class="col-md-4 control-label">Porcentaje Maximo</label>

                            <div class="col-md-6">
                                <input id="porcmax" type="text" class="form-control" name="porcmax" value="{{ old('porcmax') }}" required>

                                @if ($errors->has('porcmax'))
                                    <span class="help-block">
                                        <strong>{{ $errors->first('porcmax') }}</strong>
                                    </span>
                                @endif
                            </div>
                        </div>

                        <div class="form-group">
                            <div class="col-md-6 col-md-offset-4">
                                <button type="submit" class="btn btn-primary">
                                    Registrar
                                </button>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
<div class="container">
    <div class="row">
        <div class="col-md-8 col-md-offset-2">
            <div class="panel panel-default">
            <div class="panel-heading">Historial de Depósitos</div>
                <div class="panel-body">
                   <table class="table table-hover">
                      <thead>
                        <tr>
                          <th>Plan</th>
                          <th>Hash</th>
                          <th>Monto</th>
                          <th>Estatus</th>
                          <th>Fecha</th>
                        </tr>
                      </thead>
                      <tbody>
                        @foreach($deposits as $d)
                          <tr>
                            <td>{{$d->description}}</td>
                            <td><a href="{{$d->hash}}" target="_blank">Ir al enlace</a></td>
                            <td>{{$d->amount}}</td>
                            <td>@if($d->status=='PENDIENTE')
                                   <span class="label label-default">{{$d->status}}</span>
                                 @else
									<span class="label label-success">{{$d->status}}</span>
                                 @endif
                            </td>
                            <td>{{$d->fecha}}</td>
                          </tr>  
                        @endforeach
                        
                      </tbody>
                   </table>
                   {{ $deposits->links() }}
                </div>
            </div>
        </div>
    </div>
</div>

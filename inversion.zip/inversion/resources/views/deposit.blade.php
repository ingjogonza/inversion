@extends('layouts.app')

@section('content')

  @if(isset($editar))
    @include('layouts.editardeposit')
  @else
    @if($profile=='U')
      @include('layouts.registrardeposit')
      @include('layouts.historialdeposits')
    @else
      @include('layouts.listardeposit')
    @endif
  @endif
  
@endsection

@extends('layouts.app')

@section('content')

    @if(Auth::user()->profile=='A')
      @if(isset($editar))
      	@include('layouts.editarcashout')
      @else
      	@include('layouts.listarcashout')
      @endif
    @else
      @include('layouts.historialcashout')
    @endif
  
@endsection

@extends('layouts.app')

@section('content')
<div class="container">
    <div class="row">
        <div class="col-md-8 col-md-offset-2">
            <div class="panel panel-default">
                <div class="panel-heading">Dashboard</div>

                <div class="panel-body">
                    @include('layouts.alertas',['tipo' => 'info','mensaje' => 'Bienvenido al sistema de inversión del Ing. Jesús García, puedes ver las distintas opciones del Menú en la parte superior derecha debajo de tu nombre'])
                </div>
            </div>
        </div>
    </div>
</div>
@endsection

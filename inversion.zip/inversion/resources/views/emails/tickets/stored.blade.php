@component('mail::message')
# Gracias por tu mensaje!

El Ticket con el codigo {{$codigo}} ha sido generado, sera respondido a la brevedad posible.

@component('mail::button', ['url' => '/ticket'])
Ver tus Tickets
@endcomponent

Thanks,<br>
{{ config('app.name') }}
@endcomponent

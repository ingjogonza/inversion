@component('mail::message')
# Tienes un nuevo deposito por aprobar

El usuario  {{Auth::user()->name}} hizo un deposito por  {{$deposit->amount}}$ con el hash {{$deposit->hash}}

@component('mail::button', ['url' => '/deposits'])
Aprobar Depositos
@endcomponent

Gracias,<br>
{{ config('app.name') }}
@endcomponent

@extends('layouts.app')

@section('content')
  @include('layouts.registrarticket')
@endsection

<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {
    return view('welcome');
});

Auth::routes();

Route::get('/home', 'HomeController@index');
Route::resource('/plan','Plans');
Route::resource('/usuario','Users');
Route::resource('/deposit','Deposits');
Route::resource('/investment','Investments');
Route::resource('/madurate','Madurates');
Route::resource('/cashout','Cashouts');
Route::resource('/ticket','Tickets');
Route::get('plan/{plan}/destroy',[
	'uses' => 'Plans@destroy',
	'as' => 'plan.destroy']);
Route::get('deposit/{deposit}/destroy',[
	'uses' => 'Deposits@destroy',
	'as' => 'deposit.destroy']);
Route::get('madurate/{madurate}/reinvest',[
	'uses' => 'Madurates@reinvest',
	'as' => 'madurate.reinvest']);
Route::get('madurate/{madurate}/solicitardeposito',[
	'uses' => 'Madurates@solicitardeposito',
	'as' => 'madurate.solicitardeposito']);
Route::get('madurate/{madurate}/retirototal',[
	'uses' => 'Madurates@retirototal',
	'as' => 'madurate.retirototal']);

